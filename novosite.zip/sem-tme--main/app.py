from flask import Flask, request, jsonify, render_template, session, redirect, url_for, send_from_directory
import sqlite3
import os
from datetime import datetime
import base64

app = Flask(__name__, 
            template_folder='templates',
            static_folder='static')
app.secret_key = 'sua_chave_secreta_aqui_123456'

# Configurações do banco de dados
DATABASE = 'banco.db'

def get_db_connection():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def verificar_e_atualizar_tabela(conn, nome_tabela, colunas_necessarias):
    """Verifica se uma tabela tem todas as colunas necessárias e as adiciona se faltar."""
    cursor = conn.cursor()
    
    # Verificar se a tabela existe
    cursor.execute(f"SELECT name FROM sqlite_master WHERE type='table' AND name='{nome_tabela}'")
    if not cursor.fetchone():
        return False
    
    # Obter colunas existentes
    cursor.execute(f"PRAGMA table_info({nome_tabela})")
    colunas_existentes = [coluna[1] for coluna in cursor.fetchall()]
    
    # Adicionar colunas faltantes
    for coluna in colunas_necessarias:
        if coluna not in colunas_existentes:
            try:
                # Determinar o tipo da coluna baseado no nome
                if 'senha' in coluna.lower():
                    tipo = 'TEXT'
                elif 'data' in coluna.lower():
                    tipo = 'TIMESTAMP'
                elif 'id' in coluna.lower():
                    tipo = 'INTEGER'
                else:
                    tipo = 'TEXT'
                
                cursor.execute(f"ALTER TABLE {nome_tabela} ADD COLUMN {coluna} {tipo}")
                print(f"Coluna '{coluna}' adicionada à tabela '{nome_tabela}'")
            except sqlite3.OperationalError as e:
                print(f"Erro ao adicionar coluna {coluna} à tabela {nome_tabela}: {e}")
    
    return True

def init_db():
    with app.app_context():
        conn = get_db_connection()
        
        # Tabela de usuários - versão completa
        conn.execute('''
            CREATE TABLE IF NOT EXISTS usuarios (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL,
                email TEXT UNIQUE NOT NULL,
                senha TEXT NOT NULL,
                data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Verificar e atualizar colunas da tabela usuarios
        verificar_e_atualizar_tabela(conn, 'usuarios', ['nome', 'email', 'senha', 'data_criacao'])
        
        # Tabela de clientes
        conn.execute('''
            CREATE TABLE IF NOT EXISTS clientes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL,
                telefone TEXT,
                email TEXT,
                usuario_id INTEGER,
                data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (usuario_id) REFERENCES usuarios (id)
            )
        ''')
        
        # Verificar e atualizar colunas da tabela clientes
        verificar_e_atualizar_tabela(conn, 'clientes', ['nome', 'telefone', 'email', 'usuario_id', 'data_criacao'])
        
        # Tabela de serviços
        conn.execute('''    
            CREATE TABLE IF NOT EXISTS servicos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL,
                descricao TEXT,
                imagem TEXT,
                usuario_id INTEGER,
                data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (usuario_id) REFERENCES usuarios (id)
            )
        ''')
        
        # Verificar e atualizar colunas da tabela servicos
        verificar_e_atualizar_tabela(conn, 'servicos', ['nome', 'descricao', 'imagem', 'usuario_id', 'data_criacao'])
        
        # Tabela de agendamentos
        conn.execute('''
            CREATE TABLE IF NOT EXISTS agendamentos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                cliente_id INTEGER,
                servico_id INTEGER,
                data_agendamento DATE NOT NULL,
                hora_agendamento TIME NOT NULL,
                status TEXT DEFAULT 'pendente',
                usuario_id INTEGER,
                data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (cliente_id) REFERENCES clientes (id),
                FOREIGN KEY (servico_id) REFERENCES servicos (id),
                FOREIGN KEY (usuario_id) REFERENCES usuarios (id)
            )
        ''')
        
        # Verificar e atualizar colunas da tabela agendamentos
        verificar_e_atualizar_tabela(conn, 'agendamentos', 
                                    ['cliente_id', 'servico_id', 'data_agendamento', 
                                     'hora_agendamento', 'status', 'usuario_id', 'data_criacao'])
        
        conn.commit()
        conn.close()

# Função para corrigir o banco de dados existente
def corrigir_banco_dados():
    """Corrige problemas comuns no banco de dados"""
    try:
        conn = get_db_connection()
        
        # 1. Verificar se a tabela usuarios tem senha
        cursor = conn.cursor()
        cursor.execute("PRAGMA table_info(usuarios)")
        colunas = cursor.fetchall()
        colunas_nomes = [coluna[1] for coluna in colunas]
        
        if 'senha' not in colunas_nomes:
            print("Adicionando coluna 'senha' à tabela 'usuarios'...")
            try:
                cursor.execute("ALTER TABLE usuarios ADD COLUMN senha TEXT")
                print("Coluna 'senha' adicionada com sucesso!")
            except Exception as e:
                print(f"Erro ao adicionar coluna 'senha': {e}")
        
        # 2. Verificar e corrigir dados existentes (se necessário)
        # Se houver usuários sem senha, definir uma senha padrão
        cursor.execute("SELECT id, email FROM usuarios WHERE senha IS NULL OR senha = ''")
        usuarios_sem_senha = cursor.fetchall()
        
        for usuario in usuarios_sem_senha:
            user_id, email = usuario
            # Criar senha padrão (email + '123')
            senha_padrao = email.split('@')[0] + '123'
            cursor.execute("UPDATE usuarios SET senha = ? WHERE id = ?", (senha_padrao, user_id))
            print(f"Senha definida para usuário ID {user_id}")
        
        conn.commit()
        conn.close()
        print("Banco de dados corrigido com sucesso!")
        
    except Exception as e:
        print(f"Erro ao corrigir banco de dados: {e}")

# Inicializar e corrigir banco de dados
init_db()
corrigir_banco_dados()

# =====================
# ROTAS PRINCIPAIS (PÁGINAS HTML)
# =====================

@app.route('/')
def index():
    if 'usuario_id' in session:
        return redirect(url_for('dashboard'))
    return render_template('index.html')

@app.route('/cadastro')
def cadastro_page():
    return render_template('cadastro.html')

@app.route('/dashboard')
def dashboard():
    if 'usuario_id' not in session:
        return redirect(url_for('index'))
    return render_template('dashboard.html')

@app.route('/serviços')
def servicos():
    if 'usuario_id' not in session:
        return redirect(url_for('index'))
    return render_template('serviços.html')

@app.route('/clientes')
def clientes():
    if 'usuario_id' not in session:
        return redirect(url_for('index'))
    return render_template('clientes.html')

@app.route('/agendamento')
def agendamentos():
    if 'usuario_id' not in session:
        return redirect(url_for('index'))
    return render_template('agendamento.html')

@app.route('/perfil')
def perfil():
    if 'usuario_id' not in session:
        return redirect(url_for('index'))
    return render_template('perfil.html')

# =====================
# API - AUTENTICAÇÃO
# =====================

@app.route('/api/cadastro', methods=['POST'])
def cadastro():
    try:
        data = request.get_json()
        nome = data.get('nome')
        email = data.get('email')
        senha = data.get('senha')
        
        if not nome or not email or not senha:
            return jsonify({'success': False, 'message': 'Todos os campos são obrigatórios'})
        
        conn = get_db_connection()
        
        # Verificar se email já existe
        usuario_existente = conn.execute(
            'SELECT id FROM usuarios WHERE email = ?', (email,)
        ).fetchone()
        
        if usuario_existente:
            conn.close()
            return jsonify({'success': False, 'message': 'Email já cadastrado'})
        
        # Inserir novo usuário
        conn.execute(
            'INSERT INTO usuarios (nome, email, senha) VALUES (?, ?, ?)',
            (nome, email, senha)
        )
        conn.commit()
        conn.close()
        
        return jsonify({'success': True, 'message': 'Cadastro realizado com sucesso!'})
    
    except sqlite3.OperationalError as e:
        if "no column named senha" in str(e):
            # Se ainda houver erro, tentar corrigir o banco novamente
            corrigir_banco_dados()
            return jsonify({'success': False, 'message': 'Problema no banco de dados. Tente novamente.'})
        return jsonify({'success': False, 'message': f'Erro no banco de dados: {str(e)}'})
    except Exception as e:
        return jsonify({'success': False, 'message': f'Erro no servidor: {str(e)}'})

@app.route('/api/login', methods=['POST'])
def login():
    try:
        data = request.get_json()
        email = data.get('email')
        senha = data.get('senha')
        
        conn = get_db_connection()
        usuario = conn.execute(
            'SELECT * FROM usuarios WHERE email = ? AND senha = ?', (email, senha)
        ).fetchone()
        conn.close()
        
        if usuario:
            session['usuario_id'] = usuario['id']
            session['usuario_nome'] = usuario['nome']
            session['usuario_email'] = usuario['email']
            return jsonify({'success': True, 'message': 'Login realizado com sucesso!'})
        else:
            return jsonify({'success': False, 'message': 'Email ou senha incorretos'})
    
    except sqlite3.OperationalError as e:
        if "no column named senha" in str(e):
            corrigir_banco_dados()
            return jsonify({'success': False, 'message': 'Problema no banco de dados. Tente novamente.'})
        return jsonify({'success': False, 'message': f'Erro no banco de dados: {str(e)}'})
    except Exception as e:
        return jsonify({'success': False, 'message': f'Erro no servidor: {str(e)}'})

@app.route('/api/logout')
def logout():
    session.clear()
    return jsonify({'success': True, 'message': 'Logout realizado com sucesso!'})

# ... (mantenha o resto do código igual, as outras rotas API permanecem as mesmas) ...

# =====================
# API - DADOS DO USUÁRIO
# =====================

@app.route('/api/usuario')
def api_usuario():
    if 'usuario_id' not in session:
        return jsonify({'error': 'Não autorizado'}), 401
    
    return jsonify({
        'id': session['usuario_id'],
        'nome': session['usuario_nome'],
        'email': session['usuario_email']
    })

# =====================
# ROTA PARA SERVIR ARQUIVOS ESTÁTICOS
# =====================

@app.route('/<path:filename>')
def serve_files(filename):
    try:
        return send_from_directory('.', filename)
    except:
        return "Arquivo não encontrado", 404

# Rota específica para arquivos estáticos (CSS, JS, imagens)
@app.route('/static/<path:filename>')
def serve_static(filename):
    return send_from_directory('static', filename)

# Rota para arquivos CSS dentro de subdiretórios
@app.route('/static/css/<path:filename>')
def serve_css(filename):
    return send_from_directory('static/css', filename)

# Rota para arquivos JS dentro de subdiretórios
@app.route('/static/js/<path:filename>')
def serve_js(filename):
    return send_from_directory('static/js', filename)

# Rota para imagens dentro de subdiretórios
@app.route('/static/images/<path:filename>')
def serve_images(filename):
    return send_from_directory('static/images', filename)

# =====================
# ROTA FALLBACK PARA PÁGINAS HTML
# =====================

@app.route('/<path:page>')
def serve_html_pages(page):
    # Se a página terminar com .html, tenta servir do diretório templates
    if page.endswith('.html'):
        try:
            return render_template(page)
        except:
            return "Página não encontrada", 404
    return "Recurso não encontrado", 404

# =====================
# ROTA PARA RECRIAR O BANCO DE DADOS (APENAS PARA DESENVOLVIMENTO)
# =====================

@app.route('/admin/recreate-db')
def recreate_db():
    """Rota administrativa para recriar o banco de dados (APENAS PARA DESENVOLVIMENTO)"""
    try:
        # Remover banco de dados existente
        if os.path.exists(DATABASE):
            os.remove(DATABASE)
            print("Banco de dados antigo removido")
        
        # Recriar banco
        init_db()
        print("Novo banco de dados criado")
        
        return jsonify({'success': True, 'message': 'Banco de dados recriado com sucesso!'})
    
    except Exception as e:
        return jsonify({'success': False, 'message': f'Erro ao recriar banco: {str(e)}'})

# =====================
# INICIALIZAÇÃO
# =====================

if __name__ == '__main__':
    # Criar diretórios se não existirem
    if not os.path.exists('templates'):
        os.makedirs('templates')
    
    if not os.path.exists('static'):
        os.makedirs('static')
        os.makedirs('static/css')
        os.makedirs('static/js')
        os.makedirs('static/images')
    
    print("=== SISTEMA DE AGENDAMENTO ===")
    print("Estrutura de pastas:")
    print("  templates/ - Páginas HTML")
    print("  static/css/ - Arquivos CSS")
    print("  static/js/ - Arquivos JavaScript")
    print("  static/images/ - Imagens")
    print("\nBanco de dados: banco.db")
    print("\nServidor rodando em: http://localhost:5000")
    print("\nRotas disponíveis:")
    print("  / - Login")
    print("  /cadastro - Cadastro de usuário")
    print("  /dashboard - Dashboard principal")
    print("  /servicos - Gerenciar serviços")
    print("  /clientes - Gerenciar clientes")
    print("  /agendamentos - Gerenciar agendamentos")
    print("  /perfil - Perfil do usuário")
    print("  /admin/recreate-db - Recriar banco de dados (dev)")
    print("==============================")
    
    app.run(debug=True, host='0.0.0.0', port=5000)