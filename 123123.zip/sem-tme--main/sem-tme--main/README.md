# Instalar Flask
pip install flask

# Instalar SQLite3 (geralmente já vem com Python)
pip install pysqlite3

# Para garantir que todas as dependências estejam instaladas
pip install flask sqlite3
