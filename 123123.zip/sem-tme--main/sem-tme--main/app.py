from flask import Flask, request, jsonify, render_template, session, redirect, url_for, send_from_directory, send_file
import sqlite3
import os
from datetime import datetime
import base64
import json

# =====================
# CONFIGURAÇÕES DE CAMINHOS
# =====================
import os
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TEMPLATES_DIR = os.path.join(BASE_DIR, 'templates')
STATIC_DIR = os.path.join(BASE_DIR, 'static')

app = Flask(__name__)
app.secret_key = 'sua_chave_secreta_aqui_123456'

# Configurações do banco de dados
DATABASE = os.path.join(BASE_DIR, 'banco.db')

def get_db_connection():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    """Inicializa o banco de dados com todas as tabelas necessárias"""
    conn = get_db_connection()
    
    # Tabela de usuários
    conn.execute('''
        CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            senha TEXT NOT NULL,
            data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Tabela de clientes
    conn.execute('''
        CREATE TABLE IF NOT EXISTS clientes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            telefone TEXT,
            email TEXT,
            data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            usuario_id INTEGER,
            FOREIGN KEY (usuario_id) REFERENCES usuarios (id)
        )
    ''')
    
    # Tabela de serviços
    conn.execute('''
        CREATE TABLE IF NOT EXISTS servicos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            descricao TEXT,
            imagem TEXT,
            data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            usuario_id INTEGER,
            FOREIGN KEY (usuario_id) REFERENCES usuarios (id)
        )
    ''')
    
    # Tabela de agendamentos
    conn.execute('''
        CREATE TABLE IF NOT EXISTS agendamentos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            cliente_id INTEGER NOT NULL,
            servico_id INTEGER NOT NULL,
            data_agendamento DATE NOT NULL,
            hora_agendamento TIME NOT NULL,
            status TEXT DEFAULT 'pendente',
            observacoes TEXT,
            data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            usuario_id INTEGER,
            FOREIGN KEY (cliente_id) REFERENCES clientes (id),
            FOREIGN KEY (servico_id) REFERENCES servicos (id),
            FOREIGN KEY (usuario_id) REFERENCES usuarios (id)
        )
    ''')
    
    conn.commit()
    conn.close()

def corrigir_banco_dados():
    """Corrige problemas comuns no banco de dados"""
    conn = get_db_connection()
    
    try:
        # Verificar se a coluna usuario_id existe na tabela clientes
        conn.execute("PRAGMA table_info(clientes)")
        colunas = conn.fetchall()
        colunas_nomes = [coluna['name'] for coluna in colunas]
        
        if 'usuario_id' not in colunas_nomes:
            conn.execute('ALTER TABLE clientes ADD COLUMN usuario_id INTEGER')
            print("✅ Coluna usuario_id adicionada à tabela clientes")
        
        # Verificar se a coluna usuario_id existe na tabela servicos
        conn.execute("PRAGMA table_info(servicos)")
        colunas = conn.fetchall()
        colunas_nomes = [coluna['name'] for coluna in colunas]
        
        if 'usuario_id' not in colunas_nomes:
            conn.execute('ALTER TABLE servicos ADD COLUMN usuario_id INTEGER')
            print("✅ Coluna usuario_id adicionada à tabela servicos")
        
        # Verificar se a coluna usuario_id existe na tabela agendamentos
        conn.execute("PRAGMA table_info(agendamentos)")
        colunas = conn.fetchall()
        colunas_nomes = [coluna['name'] for coluna in colunas]
        
        if 'usuario_id' not in colunas_nomes:
            conn.execute('ALTER TABLE agendamentos ADD COLUMN usuario_id INTEGER')
            print("✅ Coluna usuario_id adicionada à tabela agendamentos")
        
        conn.commit()
        
    except Exception as e:
        print(f"⚠️ Erro ao corrigir banco: {e}")
    
    conn.close()

# =====================
# INICIALIZAR BANCO DE DADOS
# =====================
if not os.path.exists(DATABASE):
    print("📦 Criando banco de dados...")
    init_db()
    print("✅ Banco de dados criado com sucesso!")
else:
    print("✅ Banco de dados já existe")
    corrigir_banco_dados()

# =====================
# FUNÇÃO AUXILIAR PARA SERVIR HTML
# =====================

def serve_html_file(filename):
    """Serve um arquivo HTML puro"""
    filepath = os.path.join(TEMPLATES_DIR, filename)
    if os.path.exists(filepath):
        return send_file(filepath)
    else:
        return f"Arquivo {filename} não encontrado", 404

# =====================
# ROTAS PRINCIPAIS (PÁGINAS HTML)
# =====================

@app.route('/')
def index():
    if 'usuario_id' in session:
        return redirect('/dashboard')
    return serve_html_file('index.html')

@app.route('/cadastro')
def cadastro_page():
    return serve_html_file('cadastro.html')

@app.route('/dashboard')
def dashboard():
    if 'usuario_id' not in session:
        return redirect('/')
    return serve_html_file('dashboard.html')

@app.route('/servicos')
def servicos():
    if 'usuario_id' not in session:
        return redirect('/')
    return serve_html_file('servicos.html')

@app.route('/clientes')
def clientes():
    if 'usuario_id' not in session:
        return redirect('/')
    return serve_html_file('clientes.html')

@app.route('/agendamento')
def agendamento():
    if 'usuario_id' not in session:
        return redirect('/')
    return serve_html_file('agendamento.html')

@app.route('/perfil')
def perfil():
    if 'usuario_id' not in session:
        return redirect('/')
    return serve_html_file('perfil.html')

@app.route('/configuracoes')
def configuracoes():
    if 'usuario_id' not in session:
        return redirect('/')
    return serve_html_file('configuracoes.html')

# =====================
# API - AUTENTICAÇÃO
# =====================

@app.route('/api/cadastro', methods=['POST'])
def cadastro():
    try:
        data = request.get_json()
        nome = data.get('nome')
        email = data.get('email')
        senha = data.get('senha')
        
        if not nome or not email or not senha:
            return jsonify({'success': False, 'message': 'Todos os campos são obrigatórios'})
        
        conn = get_db_connection()
        
        # Verificar se email já existe
        usuario_existente = conn.execute(
            'SELECT id FROM usuarios WHERE email = ?', (email,)
        ).fetchone()
        
        if usuario_existente:
            conn.close()
            return jsonify({'success': False, 'message': 'Email já cadastrado'})
        
        # Inserir novo usuário
        cursor = conn.execute(
            'INSERT INTO usuarios (nome, email, senha) VALUES (?, ?, ?)',
            (nome, email, senha)
        )
        usuario_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        # Iniciar sessão
        session['usuario_id'] = usuario_id
        session['usuario_nome'] = nome
        session['usuario_email'] = email
        
        return jsonify({'success': True, 'message': 'Cadastro realizado com sucesso!'})
    
    except Exception as e:
        return jsonify({'success': False, 'message': f'Erro no servidor: {str(e)}'})

@app.route('/api/login', methods=['POST'])
def login():
    try:
        data = request.get_json()
        email = data.get('email')
        senha = data.get('senha')
        
        conn = get_db_connection()
        usuario = conn.execute(
            'SELECT * FROM usuarios WHERE email = ? AND senha = ?', (email, senha)
        ).fetchone()
        conn.close()
        
        if usuario:
            session['usuario_id'] = usuario['id']
            session['usuario_nome'] = usuario['nome']
            session['usuario_email'] = usuario['email']
            return jsonify({'success': True, 'message': 'Login realizado com sucesso!'})
        else:
            return jsonify({'success': False, 'message': 'Email ou senha incorretos'})
    
    except Exception as e:
        return jsonify({'success': False, 'message': f'Erro no servidor: {str(e)}'})

@app.route('/api/logout')
def logout():
    session.clear()
    return jsonify({'success': True, 'message': 'Logout realizado com sucesso!'})

@app.route('/api/usuario')
def get_usuario():
    if 'usuario_id' not in session:
        return jsonify({'success': False, 'message': 'Não autorizado'}), 401
    
    return jsonify({
        'success': True,
        'id': session['usuario_id'],
        'nome': session['usuario_nome'],
        'email': session['usuario_email']
    })

# =====================
# API - DASHBOARD/ESTATÍSTICAS
# =====================

@app.route('/api/dashboard/estatisticas', methods=['GET'])
def dashboard_estatisticas():
    if 'usuario_id' not in session:
        return jsonify({'success': False, 'message': 'Não autorizado'}), 401
    
    try:
        conn = get_db_connection()
        
        # Total de clientes
        total_clientes = conn.execute(
            'SELECT COUNT(*) as total FROM clientes WHERE usuario_id = ?',
            (session['usuario_id'],)
        ).fetchone()['total']
        
        # Total de serviços
        total_servicos = conn.execute(
            'SELECT COUNT(*) as total FROM servicos WHERE usuario_id = ?',
            (session['usuario_id'],)
        ).fetchone()['total']
        
        # Total de agendamentos
        total_agendamentos = conn.execute(
            'SELECT COUNT(*) as total FROM agendamentos WHERE usuario_id = ?',
            (session['usuario_id'],)
        ).fetchone()['total']
        
        # Agendamentos hoje
        hoje = datetime.now().strftime('%Y-%m-%d')
        agendamentos_hoje = conn.execute(
            'SELECT COUNT(*) as total FROM agendamentos WHERE usuario_id = ? AND data_agendamento = ?',
            (session['usuario_id'], hoje)
        ).fetchone()['total']
        
        # Agendamentos por status
        agendamentos_pendentes = conn.execute(
            'SELECT COUNT(*) as total FROM agendamentos WHERE usuario_id = ? AND status = "pendente"',
            (session['usuario_id'],)
        ).fetchone()['total']
        
        agendamentos_concluidos = conn.execute(
            'SELECT COUNT(*) as total FROM agendamentos WHERE usuario_id = ? AND status = "concluido"',
            (session['usuario_id'],)
        ).fetchone()['total']
        
        conn.close()
        
        return jsonify({
            'success': True,
            'estatisticas': {
                'total_clientes': total_clientes,
                'total_servicos': total_servicos,
                'total_agendamentos': total_agendamentos,
                'agendamentos_hoje': agendamentos_hoje,
                'agendamentos_pendentes': agendamentos_pendentes,
                'agendamentos_concluidos': agendamentos_concluidos
            }
        })
    
    except Exception as e:
        return jsonify({'success': False, 'message': f'Erro: {str(e)}'})

# =====================
# API - CLIENTES
# =====================

@app.route('/api/clientes', methods=['GET'])
def get_clientes():
    if 'usuario_id' not in session:
        return jsonify({'success': False, 'message': 'Não autorizado'}), 401
    
    conn = get_db_connection()
    clientes = conn.execute(
        'SELECT * FROM clientes WHERE usuario_id = ? ORDER BY nome',
        (session['usuario_id'],)
    ).fetchall()
    conn.close()
    
    return jsonify([dict(cliente) for cliente in clientes])

@app.route('/api/clientes', methods=['POST'])
def create_cliente():
    if 'usuario_id' not in session:
        return jsonify({'success': False, 'message': 'Não autorizado'}), 401
    
    try:
        data = request.get_json()
        nome = data.get('nome')
        telefone = data.get('telefone', '')
        email = data.get('email', '')
        
        if not nome:
            return jsonify({'success': False, 'message': 'Nome é obrigatório'})
        
        conn = get_db_connection()
        cursor = conn.execute(
            'INSERT INTO clientes (nome, telefone, email, usuario_id) VALUES (?, ?, ?, ?)',
            (nome, telefone, email, session['usuario_id'])
        )
        cliente_id = cursor.lastrowid
        conn.commit()
        
        # Buscar cliente criado
        cliente = conn.execute(
            'SELECT * FROM clientes WHERE id = ?', (cliente_id,)
        ).fetchone()
        conn.close()
        
        return jsonify({
            'success': True,
            'message': 'Cliente criado com sucesso',
            'cliente': dict(cliente)
        })
    
    except Exception as e:
        return jsonify({'success': False, 'message': f'Erro: {str(e)}'})

@app.route('/api/clientes/<int:cliente_id>', methods=['GET'])
def get_cliente(cliente_id):
    if 'usuario_id' not in session:
        return jsonify({'success': False, 'message': 'Não autorizado'}), 401
    
    conn = get_db_connection()
    cliente = conn.execute(
        'SELECT * FROM clientes WHERE id = ? AND usuario_id = ?',
        (cliente_id, session['usuario_id'])
    ).fetchone()
    conn.close()
    
    if cliente:
        return jsonify(dict(cliente))
    else:
        return jsonify({'success': False, 'message': 'Cliente não encontrado'}), 404

@app.route('/api/clientes/<int:cliente_id>', methods=['PUT'])
def update_cliente(cliente_id):
    if 'usuario_id' not in session:
        return jsonify({'success': False, 'message': 'Não autorizado'}), 401
    
    try:
        data = request.get_json()
        nome = data.get('nome')
        telefone = data.get('telefone', '')
        email = data.get('email', '')
        
        if not nome:
            return jsonify({'success': False, 'message': 'Nome é obrigatório'})
        
        conn = get_db_connection()
        
        # Verificar se cliente pertence ao usuário
        cliente = conn.execute(
            'SELECT id FROM clientes WHERE id = ? AND usuario_id = ?',
            (cliente_id, session['usuario_id'])
        ).fetchone()
        
        if not cliente:
            conn.close()
            return jsonify({'success': False, 'message': 'Cliente não encontrado'}), 404
        
        # Atualizar cliente
        conn.execute(
            'UPDATE clientes SET nome = ?, telefone = ?, email = ? WHERE id = ?',
            (nome, telefone, email, cliente_id)
        )
        conn.commit()
        conn.close()
        
        return jsonify({'success': True, 'message': 'Cliente atualizado com sucesso'})
    
    except Exception as e:
        return jsonify({'success': False, 'message': f'Erro: {str(e)}'})

@app.route('/api/clientes/<int:cliente_id>', methods=['DELETE'])
def delete_cliente(cliente_id):
    if 'usuario_id' not in session:
        return jsonify({'success': False, 'message': 'Não autorizado'}), 401
    
    try:
        conn = get_db_connection()
        
        # Verificar se cliente pertence ao usuário
        cliente = conn.execute(
            'SELECT id FROM clientes WHERE id = ? AND usuario_id = ?',
            (cliente_id, session['usuario_id'])
        ).fetchone()
        
        if not cliente:
            conn.close()
            return jsonify({'success': False, 'message': 'Cliente não encontrado'}), 404
        
        # Verificar se cliente tem agendamentos
        agendamentos = conn.execute(
            'SELECT id FROM agendamentos WHERE cliente_id = ?',
            (cliente_id,)
        ).fetchall()
        
        if agendamentos:
            conn.close()
            return jsonify({
                'success': False, 
                'message': 'Não é possível excluir cliente com agendamentos vinculados'
            })
        
        # Excluir cliente
        conn.execute('DELETE FROM clientes WHERE id = ?', (cliente_id,))
        conn.commit()
        conn.close()
        
        return jsonify({'success': True, 'message': 'Cliente excluído com sucesso'})
    
    except Exception as e:
        return jsonify({'success': False, 'message': f'Erro: {str(e)}'})

# =====================
# API - SERVIÇOS
# =====================

@app.route('/api/servicos', methods=['GET'])
def get_servicos():
    if 'usuario_id' not in session:
        return jsonify({'success': False, 'message': 'Não autorizado'}), 401
    
    conn = get_db_connection()
    servicos = conn.execute(
        'SELECT * FROM servicos WHERE usuario_id = ? ORDER BY nome',
        (session['usuario_id'],)
    ).fetchall()
    conn.close()
    
    return jsonify([dict(servico) for servico in servicos])

@app.route('/api/servicos', methods=['POST'])
def create_servico():
    if 'usuario_id' not in session:
        return jsonify({'success': False, 'message': 'Não autorizado'}), 401
    
    try:
        data = request.get_json()
        nome = data.get('nome')
        descricao = data.get('descricao', '')
        imagem = data.get('imagem', '')
        
        if not nome:
            return jsonify({'success': False, 'message': 'Nome é obrigatório'})
        
        conn = get_db_connection()
        cursor = conn.execute(
            'INSERT INTO servicos (nome, descricao, imagem, usuario_id) VALUES (?, ?, ?, ?)',
            (nome, descricao, imagem, session['usuario_id'])
        )
        servico_id = cursor.lastrowid
        conn.commit()
        
        # Buscar serviço criado
        servico = conn.execute(
            'SELECT * FROM servicos WHERE id = ?', (servico_id,)
        ).fetchone()
        conn.close()
        
        return jsonify({
            'success': True,
            'message': 'Serviço criado com sucesso',
            'servico': dict(servico)
        })
    
    except Exception as e:
        return jsonify({'success': False, 'message': f'Erro: {str(e)}'})

@app.route('/api/servicos/<int:servico_id>', methods=['GET'])
def get_servico(servico_id):
    if 'usuario_id' not in session:
        return jsonify({'success': False, 'message': 'Não autorizado'}), 401
    
    conn = get_db_connection()
    servico = conn.execute(
        'SELECT * FROM servicos WHERE id = ? AND usuario_id = ?',
        (servico_id, session['usuario_id'])
    ).fetchone()
    conn.close()
    
    if servico:
        return jsonify(dict(servico))
    else:
        return jsonify({'success': False, 'message': 'Serviço não encontrado'}), 404

@app.route('/api/servicos/<int:servico_id>', methods=['PUT'])
def update_servico(servico_id):
    if 'usuario_id' not in session:
        return jsonify({'success': False, 'message': 'Não autorizado'}), 401
    
    try:
        data = request.get_json()
        nome = data.get('nome')
        descricao = data.get('descricao', '')
        imagem = data.get('imagem', '')
        
        if not nome:
            return jsonify({'success': False, 'message': 'Nome é obrigatório'})
        
        conn = get_db_connection()
        
        # Verificar se serviço pertence ao usuário
        servico = conn.execute(
            'SELECT id FROM servicos WHERE id = ? AND usuario_id = ?',
            (servico_id, session['usuario_id'])
        ).fetchone()
        
        if not servico:
            conn.close()
            return jsonify({'success': False, 'message': 'Serviço não encontrado'}), 404
        
        # Atualizar serviço
        conn.execute(
            'UPDATE servicos SET nome = ?, descricao = ?, imagem = ? WHERE id = ?',
            (nome, descricao, imagem, servico_id)
        )
        conn.commit()
        conn.close()
        
        return jsonify({'success': True, 'message': 'Serviço atualizado com sucesso'})
    
    except Exception as e:
        return jsonify({'success': False, 'message': f'Erro: {str(e)}'})

@app.route('/api/servicos/<int:servico_id>', methods=['DELETE'])
def delete_servico(servico_id):
    if 'usuario_id' not in session:
        return jsonify({'success': False, 'message': 'Não autorizado'}), 401
    
    try:
        conn = get_db_connection()
        
        # Verificar se serviço pertence ao usuário
        servico = conn.execute(
            'SELECT id FROM servicos WHERE id = ? AND usuario_id = ?',
            (servico_id, session['usuario_id'])
        ).fetchone()
        
        if not servico:
            conn.close()
            return jsonify({'success': False, 'message': 'Serviço não encontrado'}), 404
        
        # Verificar se serviço tem agendamentos
        agendamentos = conn.execute(
            'SELECT id FROM agendamentos WHERE servico_id = ?',
            (servico_id,)
        ).fetchall()
        
        if agendamentos:
            conn.close()
            return jsonify({
                'success': False, 
                'message': 'Não é possível excluir serviço com agendamentos vinculados'
            })
        
        # Excluir serviço
        conn.execute('DELETE FROM servicos WHERE id = ?', (servico_id,))
        conn.commit()
        conn.close()
        
        return jsonify({'success': True, 'message': 'Serviço excluído com sucesso'})
    
    except Exception as e:
        return jsonify({'success': False, 'message': f'Erro: {str(e)}'})

# =====================
# API - AGENDAMENTOS
# =====================

@app.route('/api/agendamentos', methods=['GET'])
def get_agendamentos():
    if 'usuario_id' not in session:
        return jsonify({'success': False, 'message': 'Não autorizado'}), 401
    
    conn = get_db_connection()
    
    # Buscar agendamentos com informações de cliente e serviço
    agendamentos = conn.execute('''
        SELECT 
            a.*,
            c.nome as cliente_nome,
            c.telefone as cliente_telefone,
            c.email as cliente_email,
            s.nome as servico_nome,
            s.descricao as servico_descricao
        FROM agendamentos a
        LEFT JOIN clientes c ON a.cliente_id = c.id
        LEFT JOIN servicos s ON a.servico_id = s.id
        WHERE a.usuario_id = ?
        ORDER BY a.data_agendamento DESC, a.hora_agendamento DESC
    ''', (session['usuario_id'],)).fetchall()
    
    conn.close()
    
    return jsonify([dict(agendamento) for agendamento in agendamentos])

@app.route('/api/agendamentos', methods=['POST'])
def create_agendamento():
    if 'usuario_id' not in session:
        return jsonify({'success': False, 'message': 'Não autorizado'}), 401
    
    try:
        data = request.get_json()
        cliente_id = data.get('cliente_id')
        servico_id = data.get('servico_id')
        data_agendamento = data.get('data_agendamento')
        hora_agendamento = data.get('hora_agendamento')
        status = data.get('status', 'pendente')
        observacoes = data.get('observacoes', '')
        
        # Validações
        if not all([cliente_id, servico_id, data_agendamento, hora_agendamento]):
            return jsonify({'success': False, 'message': 'Preencha todos os campos obrigatórios'})
        
        # Verificar se cliente e serviço existem e pertencem ao usuário
        conn = get_db_connection()
        
        cliente = conn.execute(
            'SELECT id FROM clientes WHERE id = ? AND usuario_id = ?',
            (cliente_id, session['usuario_id'])
        ).fetchone()
        
        if not cliente:
            conn.close()
            return jsonify({'success': False, 'message': 'Cliente não encontrado'})
        
        servico = conn.execute(
            'SELECT id FROM servicos WHERE id = ? AND usuario_id = ?',
            (servico_id, session['usuario_id'])
        ).fetchone()
        
        if not servico:
            conn.close()
            return jsonify({'success': False, 'message': 'Serviço não encontrado'})
        
        # Verificar conflito de horário
        conflito = conn.execute('''
            SELECT id FROM agendamentos 
            WHERE data_agendamento = ? 
            AND hora_agendamento = ?
            AND status != 'cancelado'
            AND usuario_id = ?
        ''', (data_agendamento, hora_agendamento, session['usuario_id'])).fetchone()
        
        if conflito:
            conn.close()
            return jsonify({'success': False, 'message': 'Já existe um agendamento neste horário'})
        
        # Criar agendamento
        cursor = conn.execute(
            '''INSERT INTO agendamentos 
               (cliente_id, servico_id, data_agendamento, hora_agendamento, status, observacoes, usuario_id)
               VALUES (?, ?, ?, ?, ?, ?, ?)''',
            (cliente_id, servico_id, data_agendamento, hora_agendamento, status, observacoes, session['usuario_id'])
        )
        agendamento_id = cursor.lastrowid
        conn.commit()
        
        # Buscar agendamento criado com informações completas
        agendamento = conn.execute('''
            SELECT 
                a.*,
                c.nome as cliente_nome,
                c.telefone as cliente_telefone,
                s.nome as servico_nome
            FROM agendamentos a
            LEFT JOIN clientes c ON a.cliente_id = c.id
            LEFT JOIN servicos s ON a.servico_id = s.id
            WHERE a.id = ?
        ''', (agendamento_id,)).fetchone()
        
        conn.close()
        
        return jsonify({
            'success': True,
            'message': 'Agendamento criado com sucesso',
            'agendamento': dict(agendamento)
        })
    
    except Exception as e:
        return jsonify({'success': False, 'message': f'Erro: {str(e)}'})

@app.route('/api/agendamentos/<int:agendamento_id>', methods=['GET'])
def get_agendamento(agendamento_id):
    if 'usuario_id' not in session:
        return jsonify({'success': False, 'message': 'Não autorizado'}), 401
    
    conn = get_db_connection()
    
    agendamento = conn.execute('''
        SELECT 
            a.*,
            c.nome as cliente_nome,
            c.telefone as cliente_telefone,
            c.email as cliente_email,
            s.nome as servico_nome,
            s.descricao as servico_descricao
        FROM agendamentos a
        LEFT JOIN clientes c ON a.cliente_id = c.id
        LEFT JOIN servicos s ON a.servico_id = s.id
        WHERE a.id = ? AND a.usuario_id = ?
    ''', (agendamento_id, session['usuario_id'])).fetchone()
    
    conn.close()
    
    if agendamento:
        return jsonify(dict(agendamento))
    else:
        return jsonify({'success': False, 'message': 'Agendamento não encontrado'}), 404

@app.route('/api/agendamentos/<int:agendamento_id>', methods=['PUT'])
def update_agendamento(agendamento_id):
    if 'usuario_id' not in session:
        return jsonify({'success': False, 'message': 'Não autorizado'}), 401
    
    try:
        data = request.get_json()
        
        # Permitir atualização parcial
        update_fields = {}
        allowed_fields = ['cliente_id', 'servico_id', 'data_agendamento', 'hora_agendamento', 'status', 'observacoes']
        
        for field in allowed_fields:
            if field in data:
                update_fields[field] = data[field]
        
        if not update_fields:
            return jsonify({'success': False, 'message': 'Nenhum campo para atualizar'})
        
        conn = get_db_connection()
        
        # Verificar se agendamento pertence ao usuário
        agendamento = conn.execute(
            'SELECT id FROM agendamentos WHERE id = ? AND usuario_id = ?',
            (agendamento_id, session['usuario_id'])
        ).fetchone()
        
        if not agendamento:
            conn.close()
            return jsonify({'success': False, 'message': 'Agendamento não encontrado'}), 404
        
        # Verificar conflito de horário se estiver atualizando data/hora
        if 'data_agendamento' in update_fields or 'hora_agendamento' in update_fields:
            data_agendamento = update_fields.get('data_agendamento', 
                conn.execute('SELECT data_agendamento FROM agendamentos WHERE id = ?', (agendamento_id,)).fetchone()[0])
            hora_agendamento = update_fields.get('hora_agendamento',
                conn.execute('SELECT hora_agendamento FROM agendamentos WHERE id = ?', (agendamento_id,)).fetchone()[0])
            
            conflito = conn.execute('''
                SELECT id FROM agendamentos 
                WHERE data_agendamento = ? 
                AND hora_agendamento = ?
                AND id != ?
                AND status != 'cancelado'
                AND usuario_id = ?
            ''', (data_agendamento, hora_agendamento, agendamento_id, session['usuario_id'])).fetchone()
            
            if conflito:
                conn.close()
                return jsonify({'success': False, 'message': 'Já existe um agendamento neste horário'})
        
        # Construir query de atualização
        set_clause = ', '.join([f"{field} = ?" for field in update_fields.keys()])
        values = list(update_fields.values())
        values.append(agendamento_id)
        
        query = f"UPDATE agendamentos SET {set_clause} WHERE id = ?"
        conn.execute(query, values)
        conn.commit()
        
        # Buscar agendamento atualizado
        agendamento_atualizado = conn.execute('''
            SELECT 
                a.*,
                c.nome as cliente_nome,
                c.telefone as cliente_telefone,
                s.nome as servico_nome
            FROM agendamentos a
            LEFT JOIN clientes c ON a.cliente_id = c.id
            LEFT JOIN servicos s ON a.servico_id = s.id
            WHERE a.id = ?
        ''', (agendamento_id,)).fetchone()
        
        conn.close()
        
        return jsonify({
            'success': True,
            'message': 'Agendamento atualizado com sucesso',
            'agendamento': dict(agendamento_atualizado)
        })
    
    except Exception as e:
        return jsonify({'success': False, 'message': f'Erro: {str(e)}'})

@app.route('/api/agendamentos/<int:agendamento_id>', methods=['DELETE'])
def delete_agendamento(agendamento_id):
    if 'usuario_id' not in session:
        return jsonify({'success': False, 'message': 'Não autorizado'}), 401
    
    try:
        conn = get_db_connection()
        
        # Verificar se agendamento pertence ao usuário
        agendamento = conn.execute(
            'SELECT id FROM agendamentos WHERE id = ? AND usuario_id = ?',
            (agendamento_id, session['usuario_id'])
        ).fetchone()
        
        if not agendamento:
            conn.close()
            return jsonify({'success': False, 'message': 'Agendamento não encontrado'}), 404
        
        # Excluir agendamento
        conn.execute('DELETE FROM agendamentos WHERE id = ?', (agendamento_id,))
        conn.commit()
        conn.close()
        
        return jsonify({'success': True, 'message': 'Agendamento excluído com sucesso'})
    
    except Exception as e:
        return jsonify({'success': False, 'message': f'Erro: {str(e)}'})

# =====================
# ROTAS DE DEBUG E ARQUIVOS ESTÁTICOS
# =====================

@app.route('/debug/files')
def debug_files():
    """Rota de debug para verificar arquivos existentes"""
    resultado = {
        'base_dir': BASE_DIR,
        'templates_folder': TEMPLATES_DIR,
        'static_folder': STATIC_DIR,
        'templates_exist': os.path.exists(TEMPLATES_DIR),
        'static_exist': os.path.exists(STATIC_DIR),
        'templates_files': [],
        'current_working_dir': os.getcwd()
    }
    
    if os.path.exists(TEMPLATES_DIR):
        resultado['templates_files'] = os.listdir(TEMPLATES_DIR)
    
    return jsonify(resultado)

@app.route('/static/<path:filename>')
def serve_static(filename):
    return send_from_directory(STATIC_DIR, filename)

@app.route('/health')
def health_check():
    return jsonify({
        'status': 'ok',
        'message': 'Servidor está funcionando',
        'session': dict(session) if session else {}
    })

@app.errorhandler(404)
def page_not_found(e):
    return "Página não encontrada. Verifique a URL.", 404

# =====================
# INICIALIZAÇÃO
# =====================

if __name__ == '__main__':
    # Verificar estrutura de diretórios
    print("=" * 60)
    print("=== VERIFICAÇÃO DE ESTRUTURA ===")
    print(f"📁 Diretório base: {BASE_DIR}")
    print(f"📁 Templates: {TEMPLATES_DIR}")
    print(f"📁 Static: {STATIC_DIR}")
    print(f"📊 Banco de dados: {DATABASE}")
    
    # Verificar pasta templates
    if not os.path.exists(TEMPLATES_DIR):
        print("❌ Pasta 'templates' não encontrada!")
        os.makedirs(TEMPLATES_DIR, exist_ok=True)
        print("   ✅ Pasta 'templates' criada automaticamente")
    else:
        print("✅ Pasta 'templates' encontrada")
        if os.path.exists(TEMPLATES_DIR):
            templates = os.listdir(TEMPLATES_DIR)
            if templates:
                print("   📄 Arquivos HTML encontrados:")
                for arquivo in templates:
                    if arquivo.endswith('.html'):
                        print(f"      • {arquivo}")
            else:
                print("   ⚠️ Nenhum arquivo HTML na pasta templates")
    
    # Verificar pasta static
    if not os.path.exists(STATIC_DIR):
        print("❌ Pasta 'static' não encontrada!")
        os.makedirs(STATIC_DIR, exist_ok=True)
        print("   ✅ Pasta 'static' criada automaticamente")
    else:
        print("✅ Pasta 'static' encontrada")
    
    print("\n=== SISTEMA DE AGENDAMENTO ===")
    print("🚀 Servidor rodando em: http://localhost:5000")
    print("\n📋 ROTAS DISPONÍVEIS:")
    print(" 1. http://localhost:5000/ - Login")
    print(" 2. http://localhost:5000/cadastro - Cadastro")
    print(" 3. http://localhost:5000/dashboard - Dashboard")
    print(" 4. http://localhost:5000/servicos - Serviços")
    print(" 5. http://localhost:5000/clientes - Clientes")
    print(" 6. http://localhost:5000/agendamento - Agendamentos")
    print(" 7. http://localhost:5000/perfil - Perfil")
    print(" 8. http://localhost:5000/configuracoes - Configurações")
    print("\n🔧 ROTAS PARA DEBUG:")
    print(" 9. http://localhost:5000/debug/files - Verificar arquivos")
    print("10. http://localhost:5000/health - Saúde do servidor")
    print("=" * 60)
    
    # Executar o servidor
    app.run(debug=True, host='0.0.0.0', port=5000)